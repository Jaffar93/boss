Plugins for personal use. I don't recommend to use these plugins as they are not customizable.
